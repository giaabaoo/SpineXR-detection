python3 test_example.py test_config.py tutorial_exps/latest.pth --work-dir tutorial_exps/ --eval 'mAP' 
# --show 
# --show-dir spinexr_exps/result_images/