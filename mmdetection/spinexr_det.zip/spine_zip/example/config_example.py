from mmcv import Config
import dataset_example
cfg = Config.fromfile('../../configs/dcn/cascade_rcnn_r101_fpn_dconv_c3-c5_1x_coco.py')
CLASSES = ('Car', 'Pedestrian', 'Cyclist')

from mmdet.apis import set_random_seed

# cfg.train_pipeline[1].with_mask = False

# Modify dataset type and path
cfg.dataset_type = 'KittiTinyDataset'
cfg.data_root = './kitti_tiny/'

cfg.data.test.type = 'KittiTinyDataset'
cfg.data.test.data_root = 'kitti_tiny/'
cfg.data.test.ann_file = 'train.txt'
cfg.data.test.img_prefix = 'training/image_2'
# cfg.data.test.classes = CLASSES


cfg.data.train.type = 'KittiTinyDataset'
cfg.data.train.data_root = 'kitti_tiny/'
cfg.data.train.ann_file = 'train.txt'
cfg.data.train.img_prefix = 'training/image_2'
# cfg.data.train.classes = CLASSES


cfg.data.val.type = 'KittiTinyDataset'
cfg.data.val.data_root = 'kitti_tiny/'
cfg.data.val.ann_file = 'val.txt'
cfg.data.val.img_prefix = 'training/image_2'
# cfg.data.val.classes = CLASSES


# modify num classes of the model in box head

# cfg.model.roi_head.bbox_head.num_classes = 3

cfg.model.roi_head.bbox_head[0].num_classes = 3
cfg.model.roi_head.bbox_head[1].num_classes = 3
cfg.model.roi_head.bbox_head[2].num_classes = 3

# cfg.norm_cfg = dict(type='BN', requires_grad=True)
# cfg.model.backbone.norm_cfg = cfg.norm_cfg

# cfg.model.roi_head.mask_roi_extractor = None
# cfg.model.roi_head.mask_head = None


# cfg.model.bbox_head.num_classes = 3
# If we need to finetune a model based on a pre-trained detector, we need to
# use load_from to set the path of checkpoints.
cfg.load_from = '../../checkpoints/cascade_rcnn_r101_fpn_dconv_c3-c5_1x_coco_20200203-3b2f0594.pth'

# Set up working dir to save files and logs.
cfg.work_dir = './tutorial_exps'

# The original learning rate (LR) is set for 8-GPU training.
# We divide it by 8 since we only use one GPU.
cfg.optimizer.lr = 0.02 / 8
cfg.lr_config.warmup = None
cfg.log_config.interval = 10

# Change the evaluation metric since we use customized dataset.
cfg.evaluation.metric = 'mAP'
# We can set the evaluation interval to reduce the evaluation times
cfg.evaluation.interval = 12
# We can set the checkpoint saving interval to reduce the storage cost
cfg.checkpoint_config.interval = 12

# Set seed thus the results are more reproducible
cfg.seed = 0
set_random_seed(0, deterministic=False)
cfg.gpu_ids = range(1)



# init_kwargs={
#     'project': 'mmdetection',
#     'entity': 'aibigdata',
#     'config': {'lr': 1e-4, 'batch_size':32},
#     'tags': ['resnet50', 'sgd'] 
# }

# # We can also use tensorboard to log the training process
# cfg.log_config.hooks = [
#     dict(type='TextLoggerHook'),
#     dict(type='TensorboardLoggerHook')]


# We can initialize the logger for training and have a look
# at the final config used for training
print(f'Config:\n{cfg.pretty_text}')

