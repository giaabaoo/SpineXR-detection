python3 test.py test_config.py spinexr_exps/latest.pth --work-dir spinexr_exps/ --eval 'bbox' 
# --show-dir spinexr_exps/result_images/
# --show 
# 