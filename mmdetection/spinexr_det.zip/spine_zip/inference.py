import mmcv
from mmcv.runner import load_checkpoint

from mmdet.apis import inference_detector, show_result_pyplot
from mmdet.models import build_detector
from config_example import cfg

# # Choose to use a config and initialize the detector
# config = '../configs/faster_rcnn/faster_rcnn_r50_caffe_fpn_mstrain_3x_coco.py'
# # Setup a checkpoint file to load
checkpoint = './spinexr_det/tutorial_exps/latest.pth'

# # Set the device to be used for evaluation
device='cuda:0'

img = '/home/dhgbao/Machine_Learning/SpineXR/detection_task/mmdetection/spinexr_det/kitti_tiny/training/image_2/000000.jpeg'

model = build_detector(cfg.model)
checkpoint = load_checkpoint(model, checkpoint, map_location=device)
model.CLASSES = checkpoint['meta']['CLASSES']

model.cfg = cfg
result = inference_detector(model, img)
model.show_result(img, result, out_file="detected_demo2.jpg")